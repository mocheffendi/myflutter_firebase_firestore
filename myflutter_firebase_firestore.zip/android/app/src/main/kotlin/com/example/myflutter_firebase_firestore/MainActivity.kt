package com.example.myflutter_firebase_firestore

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
